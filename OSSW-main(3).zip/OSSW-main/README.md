# OSSW
The Open Source Static Websites (OSSW) is coded by SecureSpark and with code collaboration with W3Schools! 
This Static Code Website is only going to get better. We are only offering a small portion. As that's all we can provide right now. As the project gets bigger & bigger we will continue to make the website more fancy and finish it. 

https://securespark.org/ossw/download


                                        How to setup the Open Source Static Website:


	First: What Type Of OS (Operating System) do you have?: Ex: Windows 10 or 11, MacOS, or Lunix.

	

	MacOS:

	1: Download the OSSW from https://securespark.org/ossw/download. (File Size: 2.46 KB)

	2: Unzip the package and save it anywhere (Recommended: Desktop)

	3: Install HomeBrew to Install Apache2. https://wpbeaches.com/installing-homebrew-on-macos-big-sur-11-2-package-manager-for-linux-apps/. You can follow the steps then come back. For extra reference https://www.javatpoint.com/how-to-install-apache-on-mac.

	4: Save the File on /usr/local/Cellar/httpd.

	5: Then (like magic) it works! 

	6: Edit the code file however you like (Recommended IDE: VSCODE)



	Windows 10: 

	1: Download the OSSW from https://securespark.org/ossw/download. (File Size: 2.46 KB)

	2: Unzip the package and save it anywhere (Recommended: Desktop)

	3: Download And Install Apache2 https://www.sitepoint.com/how-to-install-apache-on-windows/.

	4: Copy & Paste the OSSW files (ossw.html) to the location where your apache2 server is and go to 127.0.0.1 and ( like magic) it works!

	


	Lunix: 

	1: Download the OSSW from https://securespark.org/ossw/download. (File Size: 2.46 KB)

	2: Save the file to /home/username/

	3: Open up a command prompt (CMD) and do (sudo -i). 

	4: Then: “sudo apt-get install apache2 -y”

	5: Then: “cd /var/www/html”

	6: Then: “cp -a /home/username/ossw.html /var/www/html/index.html (MUST BE INDEX.HTML)”

	7: Go to 127.0.0.1 and (like magic) it works!
